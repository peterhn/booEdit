// main.cpp
//
// ICS 45C Winter 2014
// Project #4: People Just Love to Play with Words
//
// This is the main() function that launches BooEdit.
//
// DO NOT MAKE CHANGES TO THIS FILE

#include "BooEdit.hpp"



int main()
{
    runBooEdit();
    return 0;
}

